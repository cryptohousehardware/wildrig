#!/bin/bash

while true
do
./wildrig-multi --algo algo --url pool:port --user wallet --pass password
sleep 5
done
