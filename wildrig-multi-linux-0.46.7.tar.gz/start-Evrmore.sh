#!/bin/bash

while true
do
./wildrig-multi --algo evrprogpow --url stratum+tcp://eu.evrpool.org:1111 --user EXvMVgsLdLFQkHrA63F4nS2WpKwuMxtAKH --pass x
sleep 5
done
