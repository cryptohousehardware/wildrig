#!/bin/bash

while true
do
./wildrig-multi --algo kawpow --url stratum+tcps://stratum-eu.rplant.xyz:17069 --worker test --user PoolDonateWallet --pass x
sleep 5
done
