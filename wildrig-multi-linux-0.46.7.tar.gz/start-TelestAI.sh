#!/bin/bash

while true
do
./wildrig-multi --algo progpow-telestai --url stratum+tcp://stratum.coinminerz.com:3351 --worker test --user PoolDonateWallet --pass x
sleep 5
done
