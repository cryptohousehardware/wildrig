#!/bin/bash

while true
do
./wildrig-multi --algo progpow-quai --url stratum+tcp://quai.luckypool.io:3333 --user 0x00468CF5bCE8868DFA8e4d5b5CC9018E284306B6 --pass x
sleep 5
done
