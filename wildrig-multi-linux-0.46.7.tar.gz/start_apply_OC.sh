#!/bin/bash

while true
do
./wildrig-multi --gpu-core-clock VALUE --gpu-memory-clock VALUE --gpu-core-offset VALUE --gpu-memory-offset VALUE --gpu-power-limit VALUE --algo ALGORITHM --url POOL:PORT --user WALLET --pass PASSWORD
sleep 5
done
