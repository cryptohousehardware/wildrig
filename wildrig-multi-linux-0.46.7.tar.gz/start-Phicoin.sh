#!/bin/bash

while true
do
./wildrig-multi --algo phihash --url stratum+tcps://stratum-eu.rplant.xyz:17134 --user PoolDonateWallet --pass x
sleep 5
done
